<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;

class FormController extends Controller {


  public function ajaxGetData() {
    $validator = Validator::make(request()->all(), [
      'name' => 'required',
      'email' => 'required|email',
      'message' => 'required'
    ]);

    if ($validator->fails()) {
      return [
        'status' => -1,
        'errors' => $validator->errors()->all()
      ];
    }

    //alert()->message('پیام با موفقیت ارسال شد', 'با تشکر از شما');

    return [
      'status' => 1,
      'data' => request()->all()
      ];

  }
}
