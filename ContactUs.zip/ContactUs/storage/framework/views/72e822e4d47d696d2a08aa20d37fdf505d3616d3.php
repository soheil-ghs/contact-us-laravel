<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>تماس با ما</title>

    <link rel="stylesheet" href="/css/admin.css">
    <link rel="stylesheet" href="/css/sweetalert.css">

</head>

<body>

<div id="app" class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <div class="panel panel-default">

                <div class="panel-heading">
                    <h5 style="text-align: center;">
                        فرم تماس با ما
                    </h5>
                </div>

                <div class="panel-body">

                    <div class="alert alert-danger" id="errors-container" style="display: none;">
                        <ul id="errors">
                        </ul>
                    </div>

                    <form id="form">

                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="name">نام : </label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="نام">
                        </div>

                        <div class="form-group">
                            <label for="email">ایمیل : </label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="ایمیل">
                        </div>

                        <div class="form-group">
                            <label for="message">پیام : </label>
                            <textarea class="form-control" id="message" name="message" rows="6"
                                      placeholder="لطفا پیام خود را بنویسید"></textarea>
                        </div>

                        <div class="form-group" style="text-align: center">
                            <button type="submit" class="btn btn-primary">ثبت</button>
                        </div>

                    </form>
                </div>

            </div>

        </div>
    </div>

</div>

<script src="/js/app.js"></script>
<script src="/js/sweetalert.min.js"></script>
<?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>

  $(document).ready(function () {
    $('#form').on('submit', function (e) {
      e.preventDefault();
      let name = $('#name').val();
      let email = $('#email').val();
      let message = $('#message').val();

      let _token = $('input[name="_token"]').val();

      let formData = new FormData();
      formData.append('name', name);
      formData.append('email', email);
      formData.append('message', message);

      $.ajax({
        method: 'POST',
        url: '/getData',
        data: formData,
        contentType: false,
        processData: false,
        headers: {
          'X-CSRF-TOKEN': _token
        }
      })
        .done(function (msg) {
          if (msg.status === -1) {
            $("#errors-container").show();
            let error;
            $("#errors-container ul#errors").html('');

            for (error in msg.errors) {
              $("#errors-container ul#errors").append("<li>" + msg.errors[error] + "</li>");
            }
          } else if (msg.status === 1) {
            swal({
              title: "با تشکر از شما",
              text: "پیام با موفقیت ارسال شد",
              icon: "success",
              buttons: false
            });
          }
        });

    });
  });

</script>

</body>

</html>
